Rec_Rs = [100]';
Rec_Lin= [0.8450]';

semilogx(Rec_Rs,Rec_Lin,'ko'); hold on

%Double logarithmic reciprocal function.
xval = logspace(0,4,1000);

yval = -0.11574*log(4.77522e-4*log(xval));
yval = 0.89-0.12*log(log(xval));
plot(xval,yval,'k--')
