%% single
global r0 v gamma p Li Rs Ks beta

%%define initial parameters%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Rs      = 100;
gamma   = 1e-5;
Ks      = Rs^2/0.1;
beta    = 2*(gamma/Ks)^0.5;
p       = 2.753829956054687e-04;
Li      = 0.78;
r0      = 1e-4;%%approach to 0
v       = 0.165;
n       = 1000;
% xmesh   = linspace(r0,Li,n);
xmesh   = logspace(-4,log10(Li),n);

%%%%%%%%%%%%%%%
Liup       = 0.8;
Lilow      = 0.71;
% Liup       = 0.867643843173218;
% Lilow      = 0.847643843173218;
pup        = 1e-3;
plow       = 1e-4;
% pup        = p*(1+1e-2);
% plow       = p*(1-1e-2);
err_Li     = 1;
err_p      = 1;
while abs(err_p) >1e-4
while abs(err_Li)>1e-4
%%Initial Run%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xmesh   = logspace(-4,log10(Li),n);
% xmesh   = linspace(r0,Li,n);

solinit = bvpinit(xmesh, @guess1);
options = bvpset('RelTol',1e-9,'Stats','off');
sol     = bvp5c(@bvpfcn1, @bcfcn1, solinit, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
CN      = sol.y(2,end);
C       = CN + beta;
% FF      = @(xx) [C/xx(1) - 2*beta - 2*(1+v)/(1-v)*xx(2)/Rs^2;
%  xx(1)^(-2) - (beta/xx(2) + (1+v)/(1-v)/Rs^2)];
FF      = @(xx) [xx(1) - Rs/(beta*Rs^2/xx(2)+(1+v)/(1-v))^0.5;
         C/xx(1) - 2*beta - 2*(1+v)/(1-v)*xx(2)/Rs^2];
% x0      = [3;0.003]; 
x0      = [10;0.003]; 

[x]= fsolve(FF,x0);
Lo      = real(x(1));
A       = real(x(2));

uLo     = (1+v)*A*(-1/Lo + Lo/Rs^2);
uLi     = CN*log(Li) + p^2/40/CN^2*(1-Li^5) - (1-v)*beta*(1-Lo) - (CN+beta)*log(Lo) + uLo;
err_Li1 = v*CN + uLi;
err_Li  = (-v*CN - uLi)/(-v*CN)
if err_Li1>0
    Lilow = Li;
    Li    = (Liup + Lilow)/2;
end
if err_Li1<0
    Liup = Li;
    Li    = (Liup + Lilow)/2;
end
end

dwdr     = -1/2*p/sol.y(2,end);
err_p    = (1/2*dwdr^2-gamma/sol.y(2,end)+1/2*beta^2)/(1/2*dwdr^2)
Fadhe     = err_p;
    if   Fadhe > 0
        pup = p;
        p   = (pup+plow)/2;
    end
    if   Fadhe < 0
        plow= p;
        p   = (pup+plow)/2;
    end
    Liup       = 0.8;
    Lilow      = 0.71;
%     Liup       = 0.867643843173218;
%     Lilow      = 0.847643843173218;
    beta       = 2*(gamma/Ks)^0.5;
    err_Li     = 1;

end
    Nre      = sol.y(2,end);
    dwdr     = -1/2*p/sol.y(2,end);
    U        = 0;
    ContAngle= (1-1/2*dwdr^2)*Nre/(Nre-gamma+U)

%% Cycle
global r0 v gamma p Li Rs Ks beta
    Rec_p    = zeros(50,1);
    Rec_Nr   = zeros(50,1000);
    Rec_Nt   = zeros(50,1000);
    Rec_w    = zeros(50,1000);
    Rec_x    = zeros(50,1000);
    Rec_CN   = zeros(50,1);
    Rec_beta = zeros(50,1);
    Rec_gamma = logspace(-5,-3,10)';
    p     = 2.341491516679525e-04;
for i     = 1:length(Rec_gamma)
    gamma      = Rec_gamma(i);
    Rs         = 100;
    Ks         = Rs^2/1;
    beta       = 2*(gamma/Ks)^0.5;
    Li         = 0.753201607822896;
    Lo         = 16.932577964645994;
    pup        = 1.5*p;
    plow       = p;
    err_p      = 1;
    while abs(err_p) >1e-3
%%Initial Run%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xmesh   = logspace(-4,log10(Li),n);
solinit = bvpinit(xmesh, @guess1);
options = bvpset('RelTol',1e-9,'Stats','off');
sol     = bvp5c(@bvpfcn1, @bcfcn1, solinit, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);

CN      = sol.y(2,end);
C       = CN + beta;
A       = C*Lo/2;

dwdr    = -1/2*p/sol.y(2,end);
err_p   = (1/2*dwdr^2-gamma/sol.y(2,end)+1/2*beta^2)/(1/2*dwdr^2)
Fadhe     = err_p;
    if   Fadhe > 0
        pup = p;
        p   = (pup+plow)/2;
    end
    if   Fadhe < 0
        plow= p;
        p   = (pup+plow)/2;
    end
    Liup       = 0.9;
    Lilow      = 0.7;
    beta       = 2*(gamma/Ks)^0.5;
    err_Li     = 1;
end
    Rec_p(i,1)    = p;
    Rec_Nr(i,1:length(sol.x))   = sol.y(2,:)./sol.x(1,:);
    Rec_Nt(i,1:length(sol.x))   = sol.y(3,:);
    Rec_w(i,1:length(sol.x))    = sol.y(1,:);
    Rec_x(i,1:length(sol.x))    = sol.x(1,:);
    Rec_CN(i,1)   = sol.y(2,end);
    Rec_beta(i,1) = beta;
    i
end




