function res = bcfcn1(ya,yb) % boundary conditions
global r0 v

res = [yb(1)
       r0*ya(3)-v*ya(2)
       yb(3)-v*yb(2)];
% res = [yb(1)
%        r0*ya(3)-v*ya(2)
%        yb(3)+yb(2)];
end