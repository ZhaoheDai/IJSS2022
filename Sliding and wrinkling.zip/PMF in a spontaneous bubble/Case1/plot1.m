col_gray = [80 80 80]/255;
col_1    = [0 0 0]/255;
%%
kappa = (sol.y(1,1:end-2)-2*sol.y(1,2:end-1) + sol.y(1,3:end))./(sol.x(3:end)-sol.x(1:end-2));
figure(1)
plot(kappa/kappa(1));
hold on 
figure(2)
plot(sol.x)
kappa(end)/kappa(1)
%% Gamma vs h/a
figure(1)
% load('case1.mat')
loglog(Rec_gamma,Rec_w(:,1),'k-','linewidth',1.2,'color',col_1); hold on
Rec_w(:,1)./Rec_gamma.^0.25
xval = logspace(-4.25,-3.75,10);
plot(xval,0.8*xval.^(1/4),'k-','linewidth',1,'color',col_gray); hold on
plot([xval(end) xval(end)],[0.8*xval(1).^(1/4) 0.8*xval(end).^(1/4)],'k-','linewidth',1,'color',col_gray); hold on
plot([xval(1) xval(end)],[0.8*xval(1).^(1/4) 0.8*xval(1).^(1/4)],'k-','linewidth',1,'color',col_gray); hold on
    axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);    
    xlabel('$\alpha=\Gamma/Y$','interpreter','latex','fontsize',12);
    ylabel('$h/a$','interpreter','latex','fontsize',12);
    set(ax,'xscale','log');
    set(ax,'yscale','log');
    tx = text(2e-4,0.08,'$1$','FontSize',11,'interpreter','latex','color',col_gray); set(tx,'Rotation',0)
    tx = text(1e-4,0.065,'$4$','FontSize',11,'interpreter','latex','color',col_gray); set(tx,'Rotation',0)
    
hold off
%% strain distribution
% load('case1.mat')
figure(2)
i = 20;
% for i = 1:length(Rec_gamma)/2
    epsr = (Rec_Nr(i,:)-v*Rec_Nt(i,:))/Rec_w(i,1)^2;
    epst = (Rec_Nt(i,:)-v*Rec_Nr(i,:))/Rec_w(i,1)^2; 
    diff = (epsr-epst);
    [val loc] = min(diff)
    sume = (epsr + epst)/2;
    epsr(1:loc) = sume(1:loc);
    epst(1:loc) = sume(1:loc);
    plot(sol.x,epsr,'-','linewidth',1,'color',col_1); hold on
    plot(sol.x,epst,'--','linewidth',1,'color',col_1); hold on
    epsr(1)
% end
    axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);    
    xlabel('$R=r/a$','interpreter','latex','fontsize',12);
    ylabel('$\epsilon/(h/a)^2$','interpreter','latex','fontsize',12);
    xval = linspace(0,1,100);
    q    = 2.2;
    fvq  = q/8*(2*q-1-v)/(q-1);
    gvq  = 2*q-1-4*q*(q-1)/(2*q-1-v);
    yvalr=fvq*(1-gvq*xval.^(2*q-2));
    yvalt=fvq*(1-xval.^(2*q-2));
    plot(xval,yvalr,'k-','linewidth',1,'color','r'); hold on
    plot(xval,yvalt,'k--','linewidth',1,'color','r'); hold on   
    hold off
%% Profile
% load('case1.mat')
figure(3)
i = 26;

    plot(sol.x,Rec_w(i,:),'-','linewidth',1,'color',col_1); hold on
    plot(-sol.x,Rec_w(i,:),'-','linewidth',1,'color',col_1); hold on
    xval = linspace(1,1.3,100);
    plot(xval,xval*0+0,'-','linewidth',1,'color',col_1); hold on
    plot(-xval,xval*0+0,'-','linewidth',1,'color',col_1); hold on
    axis([-1.3 1.3 0 0.1])
    axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);    
    xlabel('$R=r/a$','interpreter','latex','fontsize',12);
    ylabel('$W=w/a$','interpreter','latex','fontsize',12);
%     axis off
    hold off
%% PMFs
clear
load('case1_linearized.mat')
figure(11)
%run a linear mesh first in main1

n      = 100;%%resolution
rou    = 2;%%rou  NEED
v      = 0.165;%Poisson
r      = (1+(0:n)'/n*rou); %outside
theta  = pi*(-n:n)/n;
X      = r*cos(theta);
Y      = r*sin(theta);
for i=1:1:1
    for j=1:1:(2*n+1)
        C(i,j)=0;
    end
end
for i=2:1:(n+1)
    for j=1:1:(2*n+1)
        C(i,j)=0;
    end
end
pcolor(X,Y,C);
shading interp;
hold on;

clear n1 r1 theta1 X1 Y1 C1;
n1      = 200;%%resolution
% r1      = (1:n1)'/n1;%%0 to 1
r1      = linspace(r0*10,1,n1)';
theta1  = pi*(-n1:n1)/n1;
X1      = r1*cos(theta1);
Y1      = r1*sin(theta1);

epst    = (sol.y(3,:)-v*sol.y(2,:)./sol.x(1,:))/sol.y(1,1)^2;
epsr    = (sol.y(2,:)./sol.x(1,:)-v*sol.y(3,:))/sol.y(1,1)^2;
diff    = abs(epsr-epst);
sume    = (epsr + epst)/2;
[val loc] = min(diff);
epsr(1:loc) = sume(1:loc);
epst(1:loc) = sume(1:loc);

for i=1:1:(n1-1)
    for j=1:1:(2*n1+1)
        ro = (X1(i,j)*X1(i,j)+Y1(i,j)*Y1(i,j))^0.5;
        location = round(ro*length(sol.x))+1;
        et=epst(location);
        er=epsr(location);
        de=(epsr(location+1)-epst(location+1))-(epsr(location)-epst(location));
        dr=sol.x(1,location+1)-sol.x(1,location);
        dedr=de/dr;
        C1(i,j)=sin(3*theta1(j))*(2*(er-et)/sol.x(1,location)-de/dr);
    end
end
%%%the following is to give a max and min to match other cases
max(max(C))
max(max(C1))

maxxx  = 2.9;
i=n1;
    for j=1:1:(2*n1+1)
        C1(i,j)=maxxx;
    end
pcolor(X1,Y1,C1);
shading interp;
hold on;
i=n1;
    for j=1:1:(2*n1+1)
        C1(i,j)=-maxxx;
    end
pcolor(X1,Y1,C1);
shading interp;
hold on;
axis([-1.3 1.3 -1.3 1.3])
set(gca,'linewidth',1)
set(gca,'Visible','off')
% colormap(othercolor('BuDRd_18'))
colormap(othercolor('RdBu7'))

% c = colorbar;
% c.Location = 'southoutside';
% bestv   = 0.5;
% c.Ticks = [-maxxx -bestv 0 bestv maxxx];
% set(c,'TickLabelInterpreter','latex');

t=0:pi/100:2*pi;
x=sin(t);
y=cos(t);
p=plot(x,y);
set(p,'Color','k','LineStyle','-','Linewidth',1.2)

% tx = text(-0.1,1.1,'$r=a$','FontSize',11,'interpreter','latex','color','k'); set(tx,'Rotation',0)

%% legend
maxxx  = 2.88;
bestv  = 0.63;
for i=1:1:2
    for j=1:1:100
        Cl(i,j)=maxxx*sin(j);
    end
end
pcolor(Cl,Cl,Cl);
axis([0 5 100 200])
axis off
tx = text(2.5,150,'$r=a$','FontSize',11,'interpreter','latex','color','k'); set(tx,'Rotation',0)
tx = text(2.5,150,'$|\tilde \mathbf{B}|$','FontSize',11,'interpreter','latex','color','k'); set(tx,'Rotation',0)

colormap(othercolor('RdBu7'))
bestv = 0.63;
c = colorbar;
c.Location = 'southoutside';

c.Ticks = [-2.87 -bestv 0 bestv 2.87];
set(c,'TickLabelInterpreter','latex');