%% single
global r0 v gamma p

%%define initial parameters%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gamma   = 1e-5;
p       = 1e-4;
r0      = 1e-4;%%approach to 0
v       = 0.165;
n       = 1000;
% xmesh   = linspace(r0,1,n);
xmesh   = logspace(-4,0,n);

%%Initial Run%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
solinit = bvpinit(xmesh, @guess1);
options = bvpset('RelTol',1e-9,'Stats','off');
sol     = bvp5c(@bvpfcn1, @bcfcn1, solinit, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
p/(sol.y(1,1).^3)
%%% y(1) -> w, y(2) -> phi, y(3) -> phi'
%% %%%%%%Adhesion%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dwdr     = -1/2*p/sol.y(2,end);
Fadhe    = (1/2*dwdr^2-gamma/sol.y(2,end)+(1-v*v)/2*sol.y(2,end))/(1/2*dwdr^2);
pup      = 1e-2;
plow     = 1e-6;
while (abs(Fadhe)>1e-5)
    if   Fadhe > 0
        pup = p;
        p   = (pup+plow)/2;
    end
    if   Fadhe < 0
        plow= p;
        p   = (pup+plow)/2;
    end
    sol      = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
    sol      = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
    sol      = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
    dwdr     = -1/2*p/sol.y(2,end);
    Fadhe    = (1/2*dwdr^2-gamma/sol.y(2,end)+(1-v*v)/2*sol.y(2,end))/(1/2*dwdr^2)
end
    Nr       = sol.y(2,:)./sol.x(1,:);
    dwdr     = -1/2*p*sol.x(1,:).^2./sol.y(2,:);
    w        = sol.y(1,:);
    U        = 1/2*Nr(end)*(1-v*v)*Nr(end);
    ContAngle= (1-1/2*dwdr(end)^2)*Nr(end)/(Nr(end)-gamma+U)
% plot(sol.x,dwdr);
% p/w(1)^3
%% Cycle
global r0 v gamma p
    Rec_p    = zeros(50,1);
    Rec_Nr   = zeros(50,1000);
    Rec_Nt   = zeros(50,1000);
    Rec_w    = zeros(50,1000);
    Rec_CN   = zeros(50,1);
Rec_gamma = logspace(-5,-3,50)';
for i     = 1:length(Rec_gamma)
    gamma = Rec_gamma(i);
    pup   = 10*p;
    plow  = p;
    p     = (pup+plow)/2;
    sol   = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
    sol   = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
    sol   = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
    dwdr  = -1/2*p/sol.y(2,end);
    Fadhe = (1/2*dwdr^2-gamma/sol.y(2,end)+(1-v*v)/2*sol.y(2,end))/(1/2*dwdr^2);
    while (abs(Fadhe)>1e-5)
        if   Fadhe > 0
            pup = p;
            p   = (pup+plow)/2;
        end
        if   Fadhe < 0
            plow= p;
            p   = (pup+plow)/2;
        end
        sol      = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
        sol      = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
        sol      = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
        dwdr     = -1/2*p/sol.y(2,end);
        Fadhe    = (1/2*dwdr^2-gamma/sol.y(2,end)+(1-v*v)/2*sol.y(2,end))/(1/2*dwdr^2);
    end
    Rec_p(i,1)    = p;
    Rec_Nr(i,1:length(sol.x))   = sol.y(2,:)./sol.x(1,:);
    Rec_Nt(i,1:length(sol.x))   = sol.y(3,:);
    Rec_w(i,1:length(sol.x))    = sol.y(1,:);
    Rec_x(i,1:length(sol.x))    = sol.x(1,:);
    i
end




