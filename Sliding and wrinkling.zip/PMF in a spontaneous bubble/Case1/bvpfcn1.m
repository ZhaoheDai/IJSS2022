function dydx = bvpfcn1(x,y)
global p;
dydx = zeros(3,1);
dydx = [-p*x*x/(2*y(2))
        y(3)
        -y(3)/x+y(2)/x/x-p*p*x*x*x/(8*y(2)*y(2))];
end