% clear
% global r0 v p
% 
% %%define initial parameters%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% p       = 1e-4;
% r0      = 1e-4;%%approach to 0
% v       = 0.165;
% n       = 5000;
% xmesh   = linspace(r0,1,n);
% % xmesh   = logspace(-4,0,n);
% 
% %%Initial Run%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% solinit = bvpinit(xmesh, @guess1);
% options = bvpset('RelTol',1e-9,'Stats','on');
% sol     = bvp5c(@bvpfcn1, @bcfcn1, solinit, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% p/(sol.y(1,1).^3)
figure(66)
epst    = (sol.y(3,:)-v*sol.y(2,:)./sol.x(1,:))/sol.y(1,1)^2;
epsr    = (sol.y(2,:)./sol.x(1,:)-v*sol.y(3,:))/sol.y(1,1)^2;
diff    = abs(epsr-epst);
sume    = (epsr + epst)/2;
[val loc] = min(diff);
epsr(1:loc) = sume(1:loc);
epst(1:loc) = sume(1:loc);

for i = 2:(length(sol.x)-1)
    pos(i)= sol.x(i);
    f1(i) = 2*(epsr(i)-epst(i))/sol.x(i);
    f2(i) = ((epsr(i+1)-epst(i+1))-(epsr(i-1)-epst(i-1)))/(sol.x(i+1)-sol.x(i-1));
    f3(i) = f1(i) - f2(i);
end

% plot(sol.x,epsr); hold on
% plot(sol.x,epst); hold on

plot(pos,f3,'k-','linewidth',1); hold on
max(abs(f3(find(pos>0.5))))
    xval = linspace(0,1,100);
    q    = 2.2;
    fvq  = q/8*(2*q-1-v)/(q-1);
    gvq  = 2*q-1-4*q*(q-1)/(2*q-1-v);
    yval =(2-2*q+2)*fvq*(1-gvq)*xval.^(2*q-3);
    plot(xval,yval,'k-','linewidth',1,'color','r'); hold on
    axis([0.03 1 -0.7 0.1])
axis on;ax = gca;ax.TickLabelInterpreter='latex';ax.MinorGridAlpha=0.1; ax.GridAlpha=0.1;ax.XMinorTick='on';ax.YMinorTick='on';ax.TickLength=[0.02 0.02];set(ax,'fontsize',10);set(ax,'LineWidth',0.4);    
xlabel('$R=r/a$','interpreter','latex','fontsize',12);
ylabel('$|\tilde {\mathbf{B}}|/\sin 3\theta$','interpreter','latex','fontsize',12);