function g = guess_1(x)
g = [0.001*(1-x^0.6)
     0.000001
     0.000001];
end