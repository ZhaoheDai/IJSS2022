function res = bcfcn1(ya,yb) % boundary conditions
global r0 v Li p

res = [r0*ya(3)-v*ya(2)
       yb(1)-p/6/yb(2)*(1-Li^3)
       yb(3)];
end