% clear
load('case2_linearized.mat')
% global r0 v gamma p Li Rs
% 
% %%define initial parameters%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% gamma   = 1e-5;
% p       = 1e-5;
% Li      = 0.860921;
% r0      = 1e-4;%%approach to 0
% v       = 0.165;
% n       = 2000;
% xmesh   = linspace(r0,Li,n);
% % xmesh   = logspace(-4,log10(Li),n);
% 
% %%Initial Run%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% solinit = bvpinit(xmesh, @guess1);
% options = bvpset('RelTol',1e-9,'Stats','off');
% sol     = bvp5c(@bvpfcn1, @bcfcn1, solinit, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% sol     = bvp5c(@bvpfcn1, @bcfcn1, sol, options);
% p/(sol.y(1,1).^3);

epst    = (sol.y(3,:)-v*sol.y(2,:)./sol.x(1,:))/sol.y(1,1)^2;
epsr    = (sol.y(2,:)./sol.x(1,:)-v*sol.y(3,:))/sol.y(1,1)^2;

epsr(find(sol.x<0.01)) = 0;
epst(find(sol.x<0.01)) = 0;

for i = 1:(length(sol.x)-1)
    pos(i)= sol.x(i);
    f1(i) = 2*(epsr(i)-epst(i))/sol.x(i);
    f2(i) = ((epsr(i+1)-epst(i+1))-(epsr(i)-epst(i)))/(sol.x(i+1)-sol.x(i));
    f3(i) = f1(i) - f2(i);
end

plot(sol.x,epsr); hold on
plot(sol.x,epst); hold on

plot(pos,f3); hold on
mins = max(abs(f3(find(pos>0.5))))

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xval = linspace(Li,1,1000);
f4   = 3*(1+v)*CN./xval.^2/sol.y(1,1)^2;
plot(xval,f4); hold on
mout = max(abs(f4))
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xval = linspace(1,2,1000);
f5   = 8*(1+v)*CN./xval.^3/sol.y(1,1)^2;
plot(xval,f5); hold on
mint = max(abs(f5))

