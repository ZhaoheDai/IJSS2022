This file contains codes and data used in Dai et al. IJSS 2022. To use these codes, one may need to read the notations in the published manuscript. To reproduce figures seen in Dai et al. IJSS 2022, however, one just needs to run the code titled plot# (Matlab dataset has been included in various cases). 

It may be obvious that Case1 means no-sliding, Case2 means sliding but wrinkling only inside, Case3 means sliding and wrinkling both inside and outside, and Case4 differs from Case3 by considering the residual hoop stress in the wrinkled region outside.

Please feel free to contact daizh(at)pku.edu.cn you have any question about this file or Dai et al. IJSS 2022.